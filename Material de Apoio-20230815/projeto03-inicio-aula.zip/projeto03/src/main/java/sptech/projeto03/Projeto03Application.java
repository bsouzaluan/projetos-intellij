package sptech.projeto02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto03Application {

	public static void main(String[] args) {
		SpringApplication.run(sptech.projeto02.Projeto03Application.class, args);
	}

}
