public interface Calculavel {

 public double calculaSalario();
}
